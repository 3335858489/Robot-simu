# Gazebo Classic 闭环实验文件重新整理版

## 1. MATLAB 障碍物参数

MATLAB 当前正式配置：

- `cfg.obstacle_center = [0.15, -0.05, 0.15]`
- `cfg.obstacle_radius = 0.03`

因此本包重新建立为红色球形障碍物，半径 0.03 m。

注意：你的 Gazebo Xacro 中 `world_joint` 使用 `rpy="pi pi 0"`，
因此 MATLAB/base_link 坐标 `[0.15, -0.05, 0.15]`
在 Gazebo world 坐标中对应 `[-0.15, 0.05, 0.15]`。
`gazebo.launch.py` 已经自动完成这一坐标转换，不需要手工修改。

---

## 2. 必须替换

### A. dummy-ros2.xacro

包内：
`REPLACE/dummy-ros2_description/urdf/dummy-ros2.xacro`

覆盖：
`~/dummy_ws/src/dummy-ros2_description/urdf/dummy-ros2.xacro`

修改内容：
只为 Joint1~Joint6 增加 `effort` state interface。
几何、惯量、关节、mesh、ros2_control position command 均保持原样。

### B. gazebo.launch.py

包内：
`REPLACE/dummy-ros2_description/launch/gazebo.launch.py`

覆盖：
`~/dummy_ws/src/dummy-ros2_description/launch/gazebo.launch.py`

作用：
1. 启动 Gazebo Classic
2. 生成 dummy-ros2 机械臂
3. 自动生成与 MATLAB 障碍物一致的红色球

---

## 3. 必须新增

建立目录：

```bash
mkdir -p ~/.gazebo/models/ai_dt_obstacle_sphere
```

复制：

- `ADD/home_user/.gazebo/models/ai_dt_obstacle_sphere/model.config`
- `ADD/home_user/.gazebo/models/ai_dt_obstacle_sphere/model.sdf`

到：

`~/.gazebo/models/ai_dt_obstacle_sphere/`

最终：

```text
~/.gazebo/models/ai_dt_obstacle_sphere/
├── model.config
└── model.sdf
```

---

## 4. 闭环扰动脚本

建立：

```bash
mkdir -p ~/ai_dt_gazebo_bridge
```

复制：

- `gazebo_disturbance_bridge_classic.py`
- `verify_gazebo_feedback.sh`

到：

`~/ai_dt_gazebo_bridge/`

---

## 5. 目前不要替换

以下文件保持你当前版本：

- `dummy_moveit_config/config/ros2_controllers.yaml`
- `dummy_moveit_config/config/moveit_controllers.yaml`
- `dummy-ros2_description/urdf/dummy-ros2.gazebo`
- `dummy-ros2_description/urdf/dummy-ros2.trans`
- `dummy-ros2_description/urdf/materials.xacro`
- `dummy-ros2_description/package.xml`
- `setup.cfg`

当前 arm_controller 继续使用 position command。

---

## 6. 可选 MoveIt 障碍物

`OPTIONAL_MoveIt/set_obstacle.py`

这是把 MoveIt PlanningScene 中原先的 BOX 也改为相同球体的版本：

- frame: `base_link`
- center: `[0.15, -0.05, 0.15]`
- radius: `0.03`

Gazebo 闭环实验本身不依赖这个文件。

---

## 7. 替换完成后的运行

### 终端1

```bash
cd ~/dummy_ws
colcon build --symlink-install

source /opt/ros/humble/setup.bash
source ~/dummy_ws/install/setup.bash
export ROS_DOMAIN_ID=0

ros2 launch dummy-ros2_description gazebo.launch.py
```

启动后应该自动出现：

- 微型机械臂
- 红色球形障碍物

### 终端2

```bash
source /opt/ros/humble/setup.bash
source ~/dummy_ws/install/setup.bash
export ROS_DOMAIN_ID=0

ros2 control list_controllers
ros2 control list_hardware_interfaces
ros2 topic echo /joint_states --once
```

目前应确认：
- Joint1~Joint6 effort interface 存在
- 红球位置正确

如果 effort 仍然全为 0，这是下一步的 position-PID 动力学驱动问题，
不要为了读力矩把 arm_controller 改成 effort command。
