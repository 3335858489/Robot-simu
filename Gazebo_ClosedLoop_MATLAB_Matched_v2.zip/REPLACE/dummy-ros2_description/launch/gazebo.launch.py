import os
import xacro
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    share_dir = get_package_share_directory('dummy-ros2_description')

    # ------------------------------------------------------------------
    # Robot description
    # ------------------------------------------------------------------
    xacro_file = os.path.join(share_dir, 'urdf', 'dummy-ros2.xacro')
    robot_description_config = xacro.process_file(xacro_file)
    robot_urdf = robot_description_config.toxml()

    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        parameters=[
            {
                'robot_description': robot_urdf,
                'use_sim_time': True,
            }
        ],
        output='screen',
    )

    # Gazebo Classic
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('gazebo_ros'),
                'launch',
                'gazebo.launch.py',
            ])
        ]),
    )

    # Robot
    spawn_robot = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-entity', 'dummy-ros2',
            '-topic', 'robot_description',
        ],
        output='screen',
    )

    # ------------------------------------------------------------------
    # MATLAB-matched spherical obstacle
    #
    # MATLAB/base_link coordinates:
    #   center = [ 0.15, -0.05, 0.15 ] m
    #   radius = 0.03 m
    #
    # In dummy-ros2.xacro, world -> base_link uses:
    #   rpy = [pi, pi, 0]
    # which maps p_world = diag(-1,-1,1) * p_base.
    # Therefore the physically equivalent Gazebo WORLD position is:
    #   [-0.15, +0.05, 0.15] m
    # ------------------------------------------------------------------
    obstacle_sdf = os.path.expanduser(
        '~/.gazebo/models/ai_dt_obstacle_sphere/model.sdf'
    )

    spawn_obstacle = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-entity', 'ai_dt_obstacle_sphere',
            '-file', obstacle_sdf,
            '-x', '-0.15',
            '-y', '0.05',
            '-z', '0.15',
        ],
        output='screen',
    )

    # Small delay keeps spawning deterministic while Gazebo services start.
    delayed_obstacle = TimerAction(
        period=2.0,
        actions=[spawn_obstacle],
    )

    return LaunchDescription([
        robot_state_publisher_node,
        gazebo,
        spawn_robot,
        delayed_obstacle,
    ])
