#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Publish the MATLAB-matched AI-DT spherical obstacle to the MoveIt PlanningScene.

MATLAB / base_link parameters:
    center = [0.15, -0.05, 0.15] m
    radius = 0.03 m
"""

import time
import rclpy
from rclpy.node import Node
from moveit_msgs.msg import PlanningScene, CollisionObject
from shape_msgs.msg import SolidPrimitive
from geometry_msgs.msg import Pose


class ObstacleSetter(Node):
    def __init__(self):
        super().__init__('ai_dt_obstacle_setter')
        self.scene_pub = self.create_publisher(
            PlanningScene, '/planning_scene', 10
        )
        time.sleep(1.0)

    def add_obstacle(self):
        obj = CollisionObject()
        # Use base_link so the numerical coordinates are exactly the MATLAB ones.
        obj.header.frame_id = 'base_link'
        obj.header.stamp = self.get_clock().now().to_msg()
        obj.id = 'ai_dt_obstacle_sphere'

        primitive = SolidPrimitive()
        primitive.type = SolidPrimitive.SPHERE
        primitive.dimensions = [0.03]

        pose = Pose()
        pose.position.x = 0.15
        pose.position.y = -0.05
        pose.position.z = 0.15
        pose.orientation.w = 1.0

        obj.primitives.append(primitive)
        obj.primitive_poses.append(pose)
        obj.operation = CollisionObject.ADD

        scene = PlanningScene()
        scene.world.collision_objects.append(obj)
        scene.is_diff = True

        for _ in range(10):
            self.scene_pub.publish(scene)
            time.sleep(0.1)

        self.get_logger().info(
            'Added AI-DT sphere: center=[0.15,-0.05,0.15] m, radius=0.03 m'
        )


def main():
    rclpy.init()
    node = ObstacleSetter()
    node.add_obstacle()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
