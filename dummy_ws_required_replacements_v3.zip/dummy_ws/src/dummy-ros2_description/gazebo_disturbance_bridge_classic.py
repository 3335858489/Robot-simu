#!/usr/bin/env python3
"""Gazebo Classic disturbance bridge for the MATLAB AI-DT closed-loop test.

MATLAB publishes std_msgs/Bool on /ai_dt/disturbance_enable.
True applies a persistent external wrench to link6; False clears it.
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool
from gazebo_msgs.srv import ApplyBodyWrench, ClearBodyWrenches


class DisturbanceBridge(Node):
    def __init__(self):
        super().__init__('ai_dt_gazebo_disturbance_bridge')
        self.declare_parameter('body_name', 'dummy-ros2::link6_1_1')
        self.declare_parameter('force_z', -4.905)
        self.body_name = self.get_parameter('body_name').value
        self.force_z = float(self.get_parameter('force_z').value)

        self.apply_client = self.create_client(ApplyBodyWrench, '/gazebo/apply_body_wrench')
        self.clear_client = self.create_client(ClearBodyWrenches, '/gazebo/clear_body_wrenches')
        self.status_pub = self.create_publisher(Bool, '/ai_dt/disturbance_status', 10)
        self.sub = self.create_subscription(Bool, '/ai_dt/disturbance_enable', self.on_enable, 10)
        self.enabled = False

        self.get_logger().info('Waiting for Gazebo Classic wrench services ...')
        if not self.apply_client.wait_for_service(timeout_sec=30.0):
            raise RuntimeError('/gazebo/apply_body_wrench is not available')
        if not self.clear_client.wait_for_service(timeout_sec=30.0):
            raise RuntimeError('/gazebo/clear_body_wrenches is not available')
        self.publish_status(False)
        self.get_logger().info(
            f'Ready: body={self.body_name}, disturbance Fz={self.force_z:.3f} N')

    def publish_status(self, value):
        msg = Bool()
        msg.data = bool(value)
        self.status_pub.publish(msg)

    def on_enable(self, msg):
        target = bool(msg.data)
        if target == self.enabled:
            self.publish_status(self.enabled)
            return
        if target:
            req = ApplyBodyWrench.Request()
            req.body_name = self.body_name
            req.reference_frame = 'world'
            req.reference_point.x = 0.0
            req.reference_point.y = 0.0
            req.reference_point.z = 0.0
            req.wrench.force.x = 0.0
            req.wrench.force.y = 0.0
            req.wrench.force.z = self.force_z
            req.wrench.torque.x = 0.0
            req.wrench.torque.y = 0.0
            req.wrench.torque.z = 0.0
            req.start_time.sec = 0
            req.start_time.nanosec = 0
            req.duration.sec = 3600
            req.duration.nanosec = 0
            future = self.apply_client.call_async(req)
            future.add_done_callback(self.apply_done)
        else:
            req = ClearBodyWrenches.Request()
            req.body_name = self.body_name
            future = self.clear_client.call_async(req)
            future.add_done_callback(self.clear_done)

    def apply_done(self, future):
        try:
            response = future.result()
            self.enabled = bool(response.success)
            if self.enabled:
                self.get_logger().info('Disturbance ENABLED')
            else:
                self.get_logger().error(f'Apply wrench rejected: {response.status_message}')
        except Exception as exc:
            self.enabled = False
            self.get_logger().error(f'Apply wrench failed: {exc}')
        self.publish_status(self.enabled)

    def clear_done(self, future):
        try:
            response = future.result()
            if response.success:
                self.enabled = False
                self.get_logger().info('Disturbance DISABLED')
            else:
                self.get_logger().error(f'Clear wrench rejected: {response.status_message}')
        except Exception as exc:
            self.get_logger().error(f'Clear wrench failed: {exc}')
        self.publish_status(self.enabled)


def main(args=None):
    rclpy.init(args=args)
    node = DisturbanceBridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
