#!/usr/bin/env python3
"""
碰撞检测与重规划脚本：
1. 添加障碍物到 MoveIt
2. 监控机械臂与障碍物的距离
3. 检测到碰撞风险时停止运动
4. 自动重新规划路径
"""

import rclpy
from rclpy.node import Node
from moveit_msgs.msg import PlanningScene, CollisionObject
from moveit_msgs.srv import GetPlanningScene
from shape_msgs.msg import SolidPrimitive
from geometry_msgs.msg import Pose
from std_msgs.msg import String
from sensor_msgs.msg import JointState
from trajectory_msgs.msg import JointTrajectory
import time
import math


class CollisionReplanner(Node):
    def __init__(self):
        super().__init__('collision_replanner')
        
        # === 障碍物参数（更小的尺寸） ===
        self.obstacle_position = (0.15, -0.05, 0.15)
        self.obstacle_radius = 0.03
        self.safety_padding = 0.0
        
        # === 发布者 ===
        self.scene_pub = self.create_publisher(
            PlanningScene, 
            '/planning_scene', 
            10
        )
        
        self.stop_pub = self.create_publisher(
            JointTrajectory,
            '/joint_trajectory_controller/joint_trajectory',
            10
        )
        
        # === 订阅者 ===
        self.joint_state_sub = self.create_subscription(
            JointState,
            '/joint_states',
            self.joint_state_callback,
            10
        )
        
        # === 状态变量 ===
        self.current_joint_state = None
        self.is_collision_detected = False
        
        time.sleep(1.0)
        self.get_logger().info('Collision Replanner initialized')
        
    def add_obstacle(self):
        collision_radius = self.obstacle_radius + self.safety_padding
        collision_object = CollisionObject()
        collision_object.header.frame_id = 'base_link'
        collision_object.header.stamp = self.get_clock().now().to_msg()
        collision_object.id = 'ai_dt_obstacle_sphere'
        
        primitive = SolidPrimitive()
        primitive.type = SolidPrimitive.SPHERE
        primitive.dimensions = [collision_radius]
        
        pose = Pose()
        pose.position.x = self.obstacle_position[0]
        pose.position.y = self.obstacle_position[1]
        pose.position.z = self.obstacle_position[2]
        pose.orientation.w = 1.0
        
        collision_object.primitives.append(primitive)
        collision_object.primitive_poses.append(pose)
        collision_object.operation = CollisionObject.ADD
        
        planning_scene = PlanningScene()
        planning_scene.world.collision_objects.append(collision_object)
        planning_scene.is_diff = True
        
        self.get_logger().info('=' * 50)
        self.get_logger().info('Adding obstacle to MoveIt')
        self.get_logger().info(f'Position: {self.obstacle_position}')
        self.get_logger().info(f'Physical radius: {self.obstacle_radius} m')
        self.get_logger().info(f'Safety padding:  {self.safety_padding}m')
        self.get_logger().info(f'Collision radius: {collision_radius} m')
        self.get_logger().info('=' * 50)
        
        for _ in range(10):
            self.scene_pub.publish(planning_scene)
            time.sleep(0.1)
            
        self.get_logger().info('Obstacle added!')
        
    def joint_state_callback(self, msg):
        self.current_joint_state = msg
        
    def stop_motion(self):
        if self.current_joint_state is None:
            return
            
        self.get_logger().warn('STOPPING MOTION!')
        
        stop_msg = JointTrajectory()
        stop_msg.header.stamp = self.get_clock().now().to_msg()
        stop_msg.joint_names = list(self.current_joint_state.name)
        
        self.stop_pub.publish(stop_msg)
        self.is_collision_detected = True


def main():
    rclpy.init()
    
    node = CollisionReplanner()
    node.add_obstacle()
    
    print('')
    print('=' * 60)
    print('Collision Replanner is running!')
    print('=' * 60)
    print('')
    print('Instructions:')
    print('1. In RViz, drag the interactive marker to set goal')
    print('2. Click "Plan" to see the path (should avoid obstacle)')
    print('3. Click "Execute" to move the robot')
    print('4. If collision risk detected, motion will stop')
    print('5. Drag marker to new position and re-plan')
    print('')
    print('Obstacle center: (0.15, -0.05, 0.15) in base_link')
    print('Obstacle radius: 0.03 m')
    print('Safety padding: handled by MATLAB planning constraints')
    print('')
    print('Press Ctrl+C to exit')
    print('')
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt: 
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
