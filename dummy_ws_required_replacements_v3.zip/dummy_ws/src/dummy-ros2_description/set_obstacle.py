#!/usr/bin/env python3
"""Publish the MATLAB-matched spherical obstacle to the MoveIt planning scene."""

import time
import rclpy
from rclpy.node import Node
from moveit_msgs.msg import PlanningScene, CollisionObject
from shape_msgs.msg import SolidPrimitive
from geometry_msgs.msg import Pose


class ObstacleSetter(Node):
    def __init__(self):
        super().__init__('obstacle_setter')
        self.scene_pub = self.create_publisher(PlanningScene, '/planning_scene', 10)
        time.sleep(1.0)

    def add_obstacle(self):
        # Exactly matches MATLAB ai_dt_default_config:
        # cfg.obstacle_center = [0.15, -0.05, 0.15]
        # cfg.obstacle_radius = 0.03
        center = (0.15, -0.05, 0.15)
        radius = 0.03

        obj = CollisionObject()
        obj.header.frame_id = 'base_link'
        obj.header.stamp = self.get_clock().now().to_msg()
        obj.id = 'ai_dt_obstacle_sphere'

        primitive = SolidPrimitive()
        primitive.type = SolidPrimitive.SPHERE
        primitive.dimensions = [radius]

        pose = Pose()
        pose.position.x = center[0]
        pose.position.y = center[1]
        pose.position.z = center[2]
        pose.orientation.w = 1.0

        obj.primitives.append(primitive)
        obj.primitive_poses.append(pose)
        obj.operation = CollisionObject.ADD

        scene = PlanningScene()
        scene.world.collision_objects.append(obj)
        scene.is_diff = True

        for _ in range(10):
            self.scene_pub.publish(scene)
            time.sleep(0.1)

        self.get_logger().info(
            f'Added MATLAB-matched sphere: center={center}, radius={radius:.3f} m')


def main():
    rclpy.init()
    node = ObstacleSetter()
    node.add_obstacle()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
