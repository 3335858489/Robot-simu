import os
import xacro
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    share_dir = get_package_share_directory('dummy-ros2_description')
    xacro_file = os.path.join(share_dir, 'urdf', 'dummy-ros2.xacro')
    robot_description_config = xacro.process_file(xacro_file)
    robot_urdf = robot_description_config.toxml()

    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{'robot_description': robot_urdf, 'use_sim_time': True}],
        output='screen'
    )

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('gazebo_ros'), 'launch', 'gazebo.launch.py'
            ])
        ]),
    )

    # Robot: unchanged from the original project.
    spawn_robot = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-entity', 'dummy-ros2', '-topic', 'robot_description'],
        output='screen'
    )
    delayed_spawn_robot = TimerAction(period=5.0, actions=[spawn_robot])

    # Existing table: preserved exactly as in the original launch.
    table_urdf_path = os.path.join(share_dir, 'urdf', 'table.urdf')
    spawn_table = Node(
        package='gazebo_ros', executable='spawn_entity.py',
        arguments=['-entity', 'simple_table', '-file', table_urdf_path,
                   '-x', '0.40', '-y', '0.0', '-z', '0.0'],
        output='screen'
    )
    delayed_spawn_table = TimerAction(period=5.0, actions=[spawn_table])

    # MATLAB-matched red spherical obstacle.
    # MATLAB/base_link center = [0.15, -0.05, 0.15] m, radius = 0.03 m.
    # dummy-ros2.xacro fixes base_link to world with rpy=(pi, pi, 0),
    # therefore Gazebo world coordinates are [-0.15, +0.05, +0.15] m.
    obstacle_sdf_path = os.path.join(
        share_dir, 'models', 'obstacle_box', 'model.sdf')
    spawn_obstacle = Node(
        package='gazebo_ros', executable='spawn_entity.py',
        arguments=['-entity', 'ai_dt_obstacle_sphere', '-file', obstacle_sdf_path,
                   '-x', '-0.15', '-y', '0.05', '-z', '0.15'],
        output='screen'
    )
    delayed_spawn_obstacle = TimerAction(period=6.5, actions=[spawn_obstacle])

    # Existing blue target box: preserved exactly as in the original launch.
    target_urdf_path = os.path.join(share_dir, 'urdf', 'target_box.urdf')
    spawn_target = Node(
        package='gazebo_ros', executable='spawn_entity.py',
        arguments=['-entity', 'target_box', '-file', target_urdf_path,
                   '-x', '0.40', '-y', '0.0', '-z', '0.22'],
        output='screen'
    )
    delayed_spawn_target = TimerAction(period=8.0, actions=[spawn_target])

    # Controllers: keep the existing arm/gripper action interfaces.
    load_joint_state_broadcaster = Node(
        package='controller_manager', executable='spawner',
        arguments=['joint_state_broadcaster'], output='screen')
    load_arm_controller = Node(
        package='controller_manager', executable='spawner',
        arguments=['arm_controller'], output='screen')
    load_gripper_controller = Node(
        package='controller_manager', executable='spawner',
        arguments=['gripper_controller'], output='screen')

    # Start the MATLAB-triggered Gazebo Classic disturbance bridge automatically.
    disturbance_bridge = Node(
        package='dummy-ros2_description',
        executable='gazebo_disturbance_bridge_classic.py',
        name='ai_dt_gazebo_disturbance_bridge',
        output='screen',
        parameters=[{
            'body_name': 'dummy-ros2::link6_1_1',
            'force_z': -4.905,
            'use_sim_time': True,
        }]
    )

    return LaunchDescription([
        robot_state_publisher_node,
        gazebo,
        delayed_spawn_robot,
        delayed_spawn_table,
        delayed_spawn_obstacle,
        delayed_spawn_target,
        TimerAction(period=10.0, actions=[load_joint_state_broadcaster]),
        TimerAction(period=11.0, actions=[load_arm_controller]),
        TimerAction(period=11.5, actions=[load_gripper_controller]),
        TimerAction(period=12.0, actions=[disturbance_bridge]),
    ])
