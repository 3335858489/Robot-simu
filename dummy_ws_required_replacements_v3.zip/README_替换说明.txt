本补丁基于你上传的 dummy_ws.zip 原始目录生成。

重要结论：
1. 原 dummy_ws/src/dummy-ros2_description/urdf/ 目录里没有球体文件。
   table.urdf 是灰色桌子，target_box.urdf 是 4 cm 蓝色方块。
2. 原工程中的红色障碍物文件实际位于：
   dummy_ws/src/dummy-ros2_description/models/obstacle_box/model.sdf
   但原始几何也是红色方块，不是球。
3. 本补丁不新建任何工作空间目录，直接复用 models/obstacle_box 这个已有目录，
   把其中 model.sdf 改为与 MATLAB 一致的红色球：
   MATLAB/base_link 球心 [0.15, -0.05, 0.15] m，半径 0.03 m。
4. 原有 table.urdf 和 target_box.urdf 均保留，gazebo.launch.py 仍会生成桌子和蓝色目标方块，
   同时额外自动生成 MATLAB 匹配的红色球。
5. dummy-ros2.xacro 保留 position command interface，并加入 position PID 参数与 effort state，
   这样 FollowJointTrajectory 仍发送关节位置，但 Gazebo 内部用力矩实现位置跟踪，便于得到非零 effort。
6. 新增 gazebo_disturbance_bridge_classic.py 直接放在已有 dummy-ros2_description 包根目录，
   不新建文件夹；gazebo.launch.py 会自动启动它。

替换方法：把补丁里 dummy_ws/src 下对应文件覆盖到 ~/dummy_ws/src 下相同位置。
然后执行：
cd ~/dummy_ws
colcon build --symlink-install
source /opt/ros/humble/setup.bash
source ~/dummy_ws/install/setup.bash
export ROS_DOMAIN_ID=0
ros2 launch dummy-ros2_description gazebo.launch.py

启动后检查：
ros2 control list_hardware_interfaces
ros2 topic echo /joint_states --once
ros2 topic echo /ai_dt/disturbance_status --once
